let processes = [];

function hideAllWindows() {
    document.querySelectorAll('.window').forEach(window => {
        window.style.display = "none";
    });
}

function closeApp(processName) {
    const index = processes.indexOf(processName);
    if (index !== -1) {
        processes.splice(index, 1);
        const appElement = getEBD(processName);
        appElement.style.display = "none";
        appElement.parentNode.removeChild(appElement);
		getEBD(`${processName}.dockIcon`).parentNode.removeChild(getEBD(`${processName}.dockIcon`));
        getEBD('locator:deskpad').style.display = "block";
    } else {
        alert('Failed to close app');
    }
	refreshLocator();
}

function openApp(appSrc, processName, appTitle = '', appIcon = 'programs/program.png') {
    const deskpad = getEBD('locator:deskpad');
    
    if (!processes.includes(processName)) {
        // Minimize any open processes
        processes.forEach(process => miniApp(process));

        document.body.style.cursor = "url('sysH/cursors/wait.png'), wait";
        if (deskpad) deskpad.style.display = "none";

        const title = appTitle || processName;
        const icon = appIcon;

        const windowContent = `
            <div class="window" id="${processName}">
                <div class="tabs">
                    <span style="float: left;">${title}</span>
                    <button class="closelink" onclick="closeApp('${processName}')">X</button>
                    <button class="closelink" onclick="miniApp('${processName}')">-</button>
                </div>
                <iframe class="appContents" id="${processName}.iframe" src="${appSrc}"></iframe>
            </div>`;
        document.body.insertAdjacentHTML('beforeend', windowContent);

        const dockContent = `
            <button class="dockIcon" id="${processName}.dockIcon" onclick="openApp('${appSrc}', '${processName}', '${title}', '${icon}')">
                <img src="${icon}" alt="${title}">
            </button>`;
        const dock = getEBD('locator:dock');
        if (dock) {
            dock.insertAdjacentHTML('beforeend', dockContent);
        }

        const iframe = document.getElementById(`${processName}.iframe`);
        if (iframe) {
            iframe.addEventListener('load', function() {
                const appWindow = getEBD(processName);
                if (appWindow) appWindow.style.display = "block";

                document.body.style.cursor = "url('sysH/cursors/auto.png'), auto";
                processes.push(processName);

                const dockIcon = getEBD(`${processName}.dockIcon`);
                if (dockIcon) dockIcon.classList.replace('dockIcon', 'selectedDockIcon');
            });
        }
    } else {
        processes.forEach(process => miniApp(process));

        if (deskpad) deskpad.style.display = "none";

        const appWindow = getEBD(processName);
        if (appWindow) appWindow.style.display = "block";

        const dockIcon = getEBD(`${processName}.dockIcon`);
        if (dockIcon) dockIcon.classList.replace('dockIcon', 'selectedDockIcon');
    }
    refreshLocator();
}

function miniApp(processName) {
    const appWindow = getEBD(processName);
    if (appWindow) appWindow.style.display = "none";

    const deskpad = getEBD('locator:deskpad');
    if (deskpad) deskpad.style.display = "block";

    const dockIcon = getEBD(`${processName}.dockIcon`);
    if (dockIcon) dockIcon.classList.replace('selectedDockIcon', 'dockIcon');

    refreshLocator();
}