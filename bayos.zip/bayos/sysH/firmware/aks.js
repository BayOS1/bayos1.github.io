function io(ioAction) {
    const ioControl = {
        restart: ioRestart,
        shutdown: ioShutdown
    };

    function ioShutdown() {
        window.close();
    }

    function ioRestart() {
        location.reload();
    }

    ioControl[ioAction]?.();
    log('IO: ' + ioAction);
}

function sys(sysAction) {
    const sysControl = {
        start: sysStart
    };

    function sysStart() {
        const logInfo = ["Kernel: U2"];
        logInfo.forEach(function(logItem) {
            log(logItem);
        });
        kernelStart();
    }

    sysControl[sysAction]?.();
    log('SYS: ' + sysAction);
}

function kernelStart() {
    async function loadScripts(scripts, outputElement) {
        for (const scriptSrc of scripts) {
            await new Promise((resolve) => {
                const script = document.createElement('script');
                script.src = scriptSrc;
                script.defer = true;
                script.onload = () => {
                    document.getElementById(outputElement).innerHTML = `Loaded script: ${scriptSrc}<br>`;
                    setTimeout(resolve, 50);
                };
                document.head.appendChild(script);
            });
        }
    }

    async function loadStyles(styles, outputElement) {
        await new Promise(resolve => setTimeout(resolve, 1500));
        for (const styleHref of styles) {
            await new Promise((resolve) => {
                const link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = styleHref;
                link.onload = () => {
                    document.getElementById(outputElement).innerHTML = `Loaded style: ${styleHref}<br>`;
                    setTimeout(resolve, 50);
                };
                document.head.appendChild(link);
            });
        }
    }

    async function init() {
		
        await loadStyles([
            'sysH/UI/U2.css',
            'sysH/tabs.css',
            'services/ono.css',
            'sysH/UI/lock.css',
			'services/dock.css'
        ], 'kernel:load.loadOutput');
        await loadScripts([
            'sysH/windowMgr.js',
            'sysH/tabs.js',
            'services/ono.js',
            'services/api/world.api.js',
            'services/api/device.api.js',
            'user/lock.js',
			'services/update.sys.api.js',
			'services/dock.js'
        ], 'kernel:load.loadOutput');

        getEBD('kernel:load.loadOutput').innerHTML = "Finalizing";

        if ('getBattery' in navigator) {
            navigator.getBattery().then(function(battery) {
                updateBatteryLevel(battery.level, battery.charging);
                battery.addEventListener('levelchange', function() {
                    updateBatteryLevel(battery.level, battery.charging);
                });
                battery.addEventListener('chargingchange', function() {
                    updateBatteryLevel(battery.level, battery.charging);
                });
            });
        } else {
            noti("Battery information not supported");
        }

        setInterval(worldAPIupdate, 250);

		loadLockBG();

		getEBD('kernel:load.loadOutput').innerHTML = "Finished";

        $("#kernel\\:load").fadeTo("slow", 0, function() {
            $(this).css("display", "none");
            $("#locator\\:lock").fadeTo("slow", 1, function() {
                $(this).css("display", "block");
            });
        });        
    }

    init();
}