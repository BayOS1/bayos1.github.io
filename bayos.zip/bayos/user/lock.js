function lockCheckEnter(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        lockSubmitPassword();
    }
}

function lockCheckPassword() {
    const userPassword = getLS('userPassword') || null;
    const passwordInput = getEBD('locator:lock.lockMenu.passwordInput');

    if (userPassword == "" || userPassword == null || !userPassword) {
        userLogin();
    }
}

function lockSubmitPassword() {
    const userPassword = getLS('userPassword') || null;
    const passwordInput = getEBD('locator:lock.lockMenu.passwordInput');

    if (passwordInput.value == userPassword) {
        userLogin();
    } else {
        passwordInput.value = "";
        noti('Incorrect Password', 'Login Service');
    }
}

function userLogin() {
    const passwordInput = getEBD('locator:lock.lockMenu.passwordInput');

    passwordInput.value = "";

    const loginContent = `
    <div class="lock-middleDiv">
        <h1 id="locator:lock.time" style="display: none;">Ti:me</h1>
        <span id="locator:lock.date" style="display: none;">Date</span>
        <img style="display: none;" class="lockMenuImg" id="locator:lock.batteryImage" src="services/api/device.api.files/battery0.png">
        <span id="locator:lock.batteryStatus" style="display: none;">%</span><br>
        <img src="sysH/firmware/firmLoad.gif" width="100" height="100"><br>
    </div>
    `;
    $("#locator\\:lock.lockMenu").html(loginContent);

	loadDeskpadBG();

    setTimeout(function() { 
        $('#locator\\:lock').fadeTo("slow", 0, function() {
            $(this).css("display", "none");
            $('#locator\\:deskpad').fadeTo("slow", 1, function() {$(this).css("display", "block")});
            $('#locator\\:dock').fadeTo("slow", 1, function() {$(this).css("display", "block")});
        });
    }, 1500);
}

function showLoginMenu() {
    const loginContent = `
    <div class="lock-middleDiv">
        <h1 id="locator:lock.time">Ti:me</h1>
        <span id="locator:lock.date" style="display: none;">Date</span>
        <img style="display: none;" class="lockMenuImg" id="locator:lock.batteryImage" src="services/api/device.api.files/battery0.png">
        <span id="locator:lock.batteryStatus" style="display: none;">%</span><br><br>

        <input id="locator:lock.lockMenu.passwordInput" type="password" class="lockMenuInput" onkeydown="lockCheckEnter(event)"><button onClick="lockSubmitPassword()" class="lockMenuLogin">></button>
        <br><br>
    </div>
    `;
    $("#locator\\:lock.lockMenu").html(loginContent);
    lockCheckPassword();
}