function setNewPassword() {
    let oldPassword = getEBD('oldPassword');
    let newPassword = getEBD('newPassword');
    let confirmPassword = getEBD('confirmPassword');
    let passwordFeedback = getEBD('passwordFeedback');
    let userPassword = getLS('userPassword');

    if (!userPassword || userPassword === "") {
        userPassword = null;
    }

    if (userPassword && oldPassword.value !== userPassword) {
        showFeedback('Old Password incorrect', oldPassword, passwordFeedback, 'red');
        return;
    }

    if (newPassword.value === confirmPassword.value) {
        setLS('userPassword', newPassword.value);
        resetFields([oldPassword, newPassword, confirmPassword], 'green');
        showFeedback('Password Successfully Set', null, passwordFeedback, 'green');
    } else {
        resetFields([newPassword, confirmPassword], 'red');
        showFeedback('Passwords are not the same', null, passwordFeedback, 'red');
    }
}

function showFeedback(message, elementToReset, feedbackElement, color) {
    if (elementToReset) {
        elementToReset.value = "";
        elementToReset.style.backgroundColor = color;
        elementToReset.style.borderColor = color;
    }
    feedbackElement.style.color = color;
    feedbackElement.style.fontWeight = "bold";
    feedbackElement.innerHTML = message;

    setTimeout(function() {
        feedbackElement.innerHTML = "";
        if (elementToReset) {
            elementToReset.style.backgroundColor = "";
            elementToReset.style.borderColor = "";
        }
    }, 3000);
}

function resetFields(fields, color) {
    fields.forEach(field => {
        field.value = "";
        field.style.backgroundColor = color;
        field.style.borderColor = color;
    });

    setTimeout(function() {
        fields.forEach(field => {
            field.style.backgroundColor = "";
            field.style.borderColor = "";
        });
    }, 3000);
}