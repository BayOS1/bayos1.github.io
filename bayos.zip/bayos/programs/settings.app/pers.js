let backgrounds = [
	'../user/personalization/default.png',
	'../user/personalization/lockDefault.png',
    '../user/personalization/1.png',
    '../user/personalization/2.png',
    '../user/personalization/3.png',
    '../user/personalization/4.png',
    '../user/personalization/5.png'
];

let background = [
    'user/personalization/default.png',
	'user/personalization/lockDefault.png',
    'user/personalization/1.png',
    'user/personalization/2.png',
    'user/personalization/3.png',
    'user/personalization/4.png',
    'user/personalization/5.png'
];

let currentIndex = 0;

const slideElement = document.getElementById('slide');
const dotsContainer = document.querySelector('.dots');

backgrounds.forEach((_, index) => {
    const dot = document.createElement('span');
    dot.classList.add('dot');
    if (index === 0) dot.classList.add('active');
    dot.addEventListener('click', () => jumpToSlide(index));
    dotsContainer.appendChild(dot);
});

function showSlide(index) {
    currentIndex = index;
    slideElement.src = backgrounds[index];
    updateActiveDot();
}

function showNextSlide() {
    currentIndex = (currentIndex + 1) % backgrounds.length;
    showSlide(currentIndex);
}

function showPrevSlide() {
    currentIndex = (currentIndex - 1 + backgrounds.length) % backgrounds.length;
    showSlide(currentIndex);
}

function updateActiveDot() {
    document.querySelectorAll('.dot').forEach((dot, index) => {
        dot.classList.toggle('active', index === currentIndex);
    });
}

function jumpToSlide(index) {
    showSlide(index);
}

function applyBackground(type, element) {
    const bgTypeKey = element + 'BgType';
    const bgKey = element + 'BG';

    setLS(bgTypeKey, type);

    if (type === 'image') {
        setLS(bgKey, `url(${background[currentIndex]})`);
    } else if (type === 'color') {
        setLS(bgKey, getEBD('bgColor').value);
    }
}

document.querySelector('.next').addEventListener('click', showNextSlide);
document.querySelector('.prev').addEventListener('click', showPrevSlide);

showSlide(currentIndex);