// EaseJS Simple by GroupSSalt
// FOR VSCODE: Keep as an open tab to not get auto-corrected

const getEBD = document.getElementById.bind(document);
const getLS = localStorage.getItem.bind(localStorage);
const remLS = localStorage.removeItem.bind(localStorage);
const setLS = localStorage.setItem.bind(localStorage);
const log = console.log.bind(console);

function saveArray(keyToSave, array) {
    const jsonString = JSON.stringify(array);
    setLS(keyToSave, jsonString);
}

function loadArray(keyToLoad) {
    const jsonString = getLS(keyToLoad);
    if (jsonString) {
        return JSON.parse(jsonString);
    } else {
        return [];
    }
}

function saveBool(keyToSave, bool) {
    const jsonString = JSON.stringify(bool);
    setLS(keyToSave, jsonString);
}

function loadBool(keyToLoad) {
    const jsonString = getLS(keyToLoad);
    if (jsonString) {
        return JSON.parse(jsonString);
    } else {
        return null;
    }
}