let notificationQueue = [];
let isDisplaying = false;
let currentTimeout;
let notiTimeout = 5000;

var notificationAudio = new Audio('sysH/audio/notification.mp3');

function noti(message, appName = "Unknown", appIcon = "services/noti.png") {
    notificationQueue.push({ message, appName, appIcon });

    if (!isDisplaying) {
        isDisplaying = true;
        displayNotification();
    }
}

function displayNotification() {
    if (notificationQueue.length === 0) {
        isDisplaying = false;
        return;
    }

    var noti = document.getElementById('locator:noti');
    var p = document.getElementById('locator:noti.message');
    var notiAppName = document.getElementById('locator:noti.noti-app-name');
    var notiIcon = document.getElementById('locator:noti.noti-icon');

    var currentNotification = notificationQueue.shift();
    
    notiIcon.src = currentNotification.appIcon || "sysH/services/noti.png";
    notiAppName.innerHTML = currentNotification.appName || "???";
    p.innerHTML = currentNotification.message;

    noti.style.display = "block";
    notificationAudio.play();

    currentTimeout = setTimeout(function() {
        if (noti.style.display === "block") {
            noti.style.display = "none";
            displayNotification();
        }
    }, notiTimeout);
}

function closeNotification() {
    var noti = getEBD('locator:noti');
    noti.style.display = "none";
    clearTimeout(currentTimeout);
    displayNotification();
}