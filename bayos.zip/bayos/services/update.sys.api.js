function loadDeskpadBG() {
    let deskpadBgType = getLS('deskpadBgType') || 'image';
    let deskpadBG = getLS('deskpadBG') || "url('user/personalization/default.png')";
    if (deskpadBgType === "image") {
        document.body.style.backgroundImage = deskpadBG;
        document.body.style.backgroundSize = "100% 100%";
    } else if (deskpadBgType === "color") {
        document.body.style.backgroundImage = "none";
        document.body.style.backgroundColor = deskpadBG;
    }
}

function loadLockBG() {
    let lock = getEBD('locator:lock');
    let lockBgType = getLS('lockBgType') || 'image';
    let lockBG = getLS('lockBG') || "url('user/personalization/lockDefault.png')";
    if (lockBgType === "image") {
        lock.style.backgroundImage = lockBG;
        lock.style.backgroundSize = "100% 100%";
    } else if (lockBgType === "color") {
        lock.style.backgroundImage = "none";
        lock.style.backgroundColor = lockBG;
    }
}

function refreshLocator() {
	loadLockBG();
	loadDeskpadBG();
}