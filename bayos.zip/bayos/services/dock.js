let oldDockContent;

function showPowerOptions() {
	let dock = getEBD('locator:dock');
	
	let newContent = `
	<button class="selectedDockIcon" onClick="hidePowerOptions()"><img src="user/dock.png"></button>
	<button class="textDockIcon" onClick="refreshLocator()">Refresh</button>
	<button class="textDockIcon" onClick="io('restart')">Restart</button>
	<button class="textDockIcon" onClick="io('shutdown')">Shutdown</button>
	`;

	oldDockContent = dock.innerHTML;
	dock.innerHTML = newContent;
}

function hidePowerOptions() {
	let dock = getEBD('locator:dock');

	dock.innerHTML = oldDockContent;
}