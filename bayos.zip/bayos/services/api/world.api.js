function worldAPIupdate() {
    const currentDate = new Date();
    const currentHour = currentDate.getHours().toString().padStart(2, '0');
    const currentMinute = currentDate.getMinutes().toString().padStart(2, '0');
    let timePeriod;
    let currentTime;

    if (currentHour >= 12) {
        timePeriod = 'PM';
        currentTime = (currentHour === 12 ? currentHour : currentHour - 12) + ':' + currentMinute;
    } else {
        timePeriod = 'AM';
        currentTime = (currentHour === 0 ? 12 : currentHour) + ':' + currentMinute;
    }

    const currentDateStr = currentDate.toDateString();
    const formattedTime = currentTime + ' ' + timePeriod;

    document.getElementById('locator:lock.time').innerHTML = formattedTime;
    document.getElementById('locator:lock.date').innerHTML = currentDateStr;
    // document.getElementById('locator:dock.time').innerHTML = formattedTime;
}