let lastBatteryLevel = null;
let lastIsCharging = null;

function updateBatteryLevel(level, isCharging) {
    const batteryPercentage = Math.floor(level * 100);
    if (batteryPercentage !== lastBatteryLevel || isCharging !== lastIsCharging) {
        const batteryElement = getEBD('locator:lock.batteryImage');
        // const batteryElement2 = getEBD('locator:dock.batteryImage');
        const batteryStatusElement = getEBD('locator:lock.batteryStatus');
        // const batteryStatusElement2 = getEBD('locator:dock.batteryStatus');

        batteryStatusElement.innerHTML = batteryPercentage + '%';

        if (isCharging) {
            batteryElement.src = "services/api/device.api.files/batteryCA.png";
        } else if (batteryPercentage === 100) {
            batteryElement.src = "services/api/device.api.files/battery100.png";
        } else if (batteryPercentage >= 75) {
            batteryElement.src = "services/api/device.api.files/battery75.png";
        } else if (batteryPercentage >= 65) {
            batteryElement.src = "services/api/device.api.files/battery65.png";
        } else if (batteryPercentage >= 50) {
            batteryElement.src = "services/api/device.api.files/battery50.png";
        } else if (batteryPercentage >= 35) {
            batteryElement.src = "services/api/device.api.files/battery35.png";
        } else if (batteryPercentage >= 25) {
            batteryElement.src = "services/api/device.api.files/battery25.png";
        } else {
            batteryElement.src = "services/api/device.api.files/battery0.png";
        }

        lastBatteryLevel = batteryPercentage;
        lastIsCharging = isCharging;
    }
}